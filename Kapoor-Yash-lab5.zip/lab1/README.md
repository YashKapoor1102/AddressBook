[![Java CI with Maven](https://github.com/YashKapoor1102/AddressBook/actions/workflows/maven.yml/badge.svg)](https://github.com/YashKapoor1102/AddressBook/actions/workflows/maven.yml)
