package AddressBookLab;

import org.springframework.data.repository.CrudRepository;

public interface AddressRepository extends CrudRepository<AddressBook, Integer> {}

